1.0.0 (2020-06-26)
------------------
* Implement repeat rate and key timeout
* Update readme about publishing to another topic.
* Contributors: Austin, trainman419

0.6.2 (2018-10-21)
------------------
* Replace tabs with spaces, fixes `#15 <https://github.com/ros-teleop/teleop_twist_keyboard/issues/15>`_
* Merge pull request `#13 <https://github.com/ros-teleop/teleop_twist_keyboard/issues/13>`_ from asukiaaa/patch-3
  Add rosrun command to specify values
* Add rosrun command to specify values
* Contributors: Asuki Kono, Austin, trainman419

0.6.1 (2018-05-02)
------------------
* Merge pull request `#11 <https://github.com/ros-teleop/teleop_twist_keyboard/issues/11>`_ from MatthijsBurgh/patch-1
  Correct exception handling; Python3 print compatible
* import print from future
* Print python3 compatible
* correct Exception handling
* Merge pull request `#7 <https://github.com/ros-teleop/teleop_twist_keyboard/issues/7>`_ from lucasw/speed_params
  set linear and turn speed via rosparams
* Using tabs instead of spaces to match rest of file
* set linear and turn speed via rosparams
* Contributors: Austin, Lucas Walter, Matthijs van der Burgh

0.6.0 (2016-03-21)
------------------
* Better instruction formatting
* support holonomic base, send commmand with keyboard down
* Fixing queue_size warning
* Create README.md
* Update the description string in package.xml
* Contributors: Austin, Kei Okada, LiohAu, Mike Purvis, kk6axq, trainman419

0.5.0 (2014-02-11)
------------------
* Initial import from brown_remotelab
* Convert to catkin
